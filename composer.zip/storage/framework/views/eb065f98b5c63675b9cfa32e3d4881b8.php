<header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

    <?php echo $__env->yieldContent('sidebar-icon'); ?>

      <a href="<?php echo e(route('manager.dashboard')); ?>" class="logo d-flex align-items-center me-auto me-lg-0 ms-4">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="user/assets/img/logo.png" alt=""> --> 
        <h1>Yummy<span>Cafe.</span></h1>
      </a>

            <!-- Navbar-->
            <ul class="navbar-nav ms-auto me-5">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><svg class="svg-inline--fa fa-user fa-fw" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z"></path></svg><!-- <i class="fas fa-user fa-fw"></i> Font Awesome fontawesome.com --></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <?php if(auth()->check()): ?>
                            <p>Logged in as: <?php echo e(auth()->user()->name); ?></p>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Logout</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>">Log in</a>
                        <?php endif; ?>
                        
                    </ul>
                </li>
            </ul>

    </div>
  </header>

  
<?php /**PATH D:\6th Semester\Summer Project\cafeteria-system\resources\views/layouts/header.blade.php ENDPATH**/ ?>