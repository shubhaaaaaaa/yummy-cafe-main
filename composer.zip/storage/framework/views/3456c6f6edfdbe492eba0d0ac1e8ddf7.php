<footer id="footer" class="footer">
      <div class="copyright">
        &copy; Copyright 2023 <strong><span>Yummy</span>Cafe</strong>. All Rights Reserved
      </div>
</footer>
<?php /**PATH D:\6th Semester\Summer Project\cafeteria-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>