<section id="menu" class="menu">
  <div class="container" data-aos="fade-up">
    <div class="section-header">
      <h2>Our Yummy Menu</h2>
    </div>
    <ul class="nav nav-tabs d-flex justify-content-center" data-aos="fade-up" data-aos-delay="200">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
          <a class="nav-link<?php echo e($loop->first ? ' active show' : ''); ?>" data-bs-toggle="tab" href="#menu-<?php echo e(Str::slug($category->name)); ?>">
            <h4><?php echo e($category->name); ?></h4>
          </a>
        </li><!-- End tab nav item -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="tab-content" data-aos="fade-up" data-aos-delay="300">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane fade<?php echo e($loop->first ? ' active show' : ''); ?>" id="menu-<?php echo e(Str::slug($category->name)); ?>">
          <div class="row gy-5">
            <!-- Display products for the current category -->
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6">
                <div class="menu-item">
                  <h3><?php echo e($product->name); ?></h3>
                  <p><?php echo e($product->description); ?></p>
                  <!-- Additional product details can be added here -->
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section><!-- End Menu Section -->

<?php /**PATH D:\6th Semester\Summer Project\cafeteria-system\resources\views/user/menu.blade.php ENDPATH**/ ?>