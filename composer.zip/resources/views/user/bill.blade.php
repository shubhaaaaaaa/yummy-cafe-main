<!DOCTYPE html>
<html>
<head>
    <title>My Site</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<div class="invoice-window">
        <div class="invoice-content">
            <div class="bill-header">
                <h2>Invoice</h2>
                <div class="bill-details">
                    <p><strong>Invoice No:</strong> INV-1234</p>
                    <p><strong>Order No:</strong> ORD-5678</p>
                    <p><strong>Date:</strong> <span id="currentDate"></span></p>
                    <p><strong>Time:</strong> <span id="currentTime"></span></p>
                </div>
            </div>
            <div class="bill-table">
                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="billItems"></tbody>
                </table>
            </div>
            <div class="bill-footer row">
                <div class="col-5"> 
                <img class="qrcode" src="assets\img\qrcode.png" alt="QR Code">
                </div>
                <div class="col">
                    <div class="bill-subtotal">
                        <p><strong>Subtotal:</strong> <span id="subtotal">Rs 0</span></p>
                    </div>
                    <div class="bill-taxes">
                        <p><strong>Taxes:</strong> <span id="taxes">Rs 0</span></p>
                    </div>
                    <div class="bill-total">
                        <p><strong>Total:</strong> <span id="total">Rs 0</span></p>
                    </div>
                    <div class="mb-5 mt-2">
                        <button class="confirm-order-btn align-right-btn">Confirm Order</button>
                    </div>

                </div>
            </div>
        </div>
    </div>


</body>
</html>
