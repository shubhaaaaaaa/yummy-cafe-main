<section id="menu" class="menu">
  <div class="container" data-aos="fade-up">
    <div class="section-header">
      <h2>Our Yummy Menu</h2>
    </div>
    <ul class="nav nav-tabs d-flex justify-content-center" data-aos="fade-up" data-aos-delay="200">
      @foreach($categories as $category)
        <li class="nav-item">
          <a class="nav-link{{ $loop->first ? ' active show' : '' }}" data-bs-toggle="tab" href="#menu-{{ Str::slug($category->name) }}">
            <h4>{{ $category->name }}</h4>
          </a>
        </li><!-- End tab nav item -->
      @endforeach
    </ul>

    <div class="tab-content" data-aos="fade-up" data-aos-delay="300">
      @foreach($categories as $category)
        <div class="tab-pane fade{{ $loop->first ? ' active show' : '' }}" id="menu-{{ Str::slug($category->name) }}">
          <div class="row gy-5">
            <!-- Display products for the current category -->
            @foreach($category->products as $product)
              <div class="col-lg-4 col-md-6">
                <div class="menu-item">
                  <h3>{{ $product->name }}</h3>
                  <p>{{ $product->description }}</p>
                  <!-- Additional product details can be added here -->
                </div>
              </div>
            @endforeach
          </div>
        </div>
      @endforeach
    </div>
  </div>
</section><!-- End Menu Section -->

