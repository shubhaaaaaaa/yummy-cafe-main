function addToBill(item, price) {
    var quantity = 1; // You can update this value based on your requirements
    var total = quantity * price;

    var billItems = document.getElementById("billItems");
    var newRow = document.createElement("tr");

    newRow.innerHTML = `
        <td>${item}</td>
        <td>${quantity}</td>
        <td>Rs ${price}</td>
        <td>Rs ${total}</td>
    `;

    billItems.appendChild(newRow);

    calculateTotals();
}

function calculateTotals() {
    var itemRows = document.querySelectorAll("#billItems tr");
    var subtotal = 0;

    itemRows.forEach(function(row) {
        var price = parseInt(row.cells[2].innerText.replace("Rs ", ""));
        var quantity = parseInt(row.cells[1].innerText);
        var total = price * quantity;

        row.cells[3].innerText = "Rs " + total;
        subtotal += total;
    });

    var taxes = 0.1 * subtotal; // Assuming 10% tax
    var total = subtotal + taxes;

    document.getElementById("subtotal").innerText = "Rs " + subtotal;
    document.getElementById("taxes").innerText = "Rs " + taxes;
    document.getElementById("total").innerText = "Rs " + total;
}

// Get the current date and time
var currentDateElement = document.getElementById("currentDate");
var currentTimeElement = document.getElementById("currentTime");

var currentDate = new Date().toLocaleDateString();
var currentTime = new Date().toLocaleTimeString();

currentDateElement.innerText = currentDate;
currentTimeElement.innerText = currentTime;

