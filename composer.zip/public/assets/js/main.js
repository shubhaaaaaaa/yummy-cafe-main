document.addEventListener('DOMContentLoaded', () => {
  "use strict";


  /**
   * Sticky header on scroll
   */
  const selectHeader = document.querySelector('#header');
  if (selectHeader) {
    document.addEventListener('scroll', () => {
      window.scrollY > 100 ? selectHeader.classList.add('sticked') : selectHeader.classList.remove('sticked');
    });
  }

  // Scroll to the top of the page when it is refreshed
window.addEventListener('beforeunload', function () {
  window.scrollTo(0, 0);
});

  // Animation on scroll function and init
function aos_init() {
  AOS.init({
    duration: 1000,
    easing: 'ease-in-out',
    once: true,
    mirror: false
  });
}

// Delay the initialization of AOS until after the page has loaded and scroll position has been adjusted
window.addEventListener('load', () => {
  window.scrollTo(0, 0); // Scroll to the top of the page first
  setTimeout(() => {
    aos_init(); // Initialize AOS after a small delay
  }, 100);
});

// invoice.js
(function() {
  function updateDateTime() {
    var currentDate = new Date();
    var currentTime = currentDate.toLocaleTimeString();
    currentDate = currentDate.toLocaleDateString();

    document.getElementById('currentDate').textContent = currentDate;
    document.getElementById('currentTime').textContent = currentTime;
  }

  // Update date and time initially
  updateDateTime();

  // Update date and time every second
  setInterval(updateDateTime, 1000);
})();

const tabLinks = document.querySelectorAll('.nav-link');
const tabContents = document.querySelectorAll('.tab-pane');

tabLinks.forEach((link, index) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = link.getAttribute('href');

    // Remove active class from all tab links and tab contents
    tabLinks.forEach(tabLink => tabLink.classList.remove('active', 'show'));
    tabContents.forEach(tabContent => tabContent.classList.remove('active', 'show'));

    // Add active class to the clicked tab link and corresponding tab content
    link.classList.add('active', 'show');
    document.querySelector(target).classList.add('active', 'show');
  });
});

});